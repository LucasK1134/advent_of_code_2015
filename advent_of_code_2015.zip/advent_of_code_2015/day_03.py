with open('/Users/kezhikun/PycharmProjects/advent_of_code_2015/input/day_03.txt', 'r') as file_object:
    directions = file_object.read().strip()
visited_houses = set()
x, y = 0, 0
visited_houses.add((x, y))
for move in directions:
    if move == '^':
        y += 1
    elif move == 'v':
        y -= 1
    elif move == '>':
        x += 1
    elif move == '<':
        x -= 1
    visited_houses.add((x, y))
total_houses = len(visited_houses)
print(f"2015 Day3 Part1 Answer: {total_houses}")

with open('/Users/kezhikun/PycharmProjects/advent_of_code_2015/input/day_03.txt', 'r') as file_object:
    directions = file_object.read().strip()
visited_houses = set()
santa_x, santa_y = 0, 0
robo_x, robo_y = 0, 0
visited_houses.add((santa_x, santa_y))
for idx, move in enumerate(directions):
    if idx % 2 == 0:
        if move == '^':
            santa_y += 1
        elif move == 'v':
            santa_y -= 1
        elif move == '>':
            santa_x += 1
        elif move == '<':
            santa_x -= 1
        visited_houses.add((santa_x, santa_y))
    else:
        if move == '^':
            robo_y += 1
        elif move == 'v':
            robo_y -= 1
        elif move == '>':
            robo_x += 1
        elif move == '<':
            robo_x -= 1
        visited_houses.add((robo_x, robo_y))
total_houses = len(visited_houses)
print(f"2015 Day3 Part2 Answer: {total_houses}")