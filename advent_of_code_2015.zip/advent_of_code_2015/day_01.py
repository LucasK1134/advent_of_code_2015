with open('/Users/kezhikun/PycharmProjects/advent_of_code_2015/input/day_01.txt', 'r') as file_object:
    instructions = file_object.read().strip()
current_floor = 0
for char in instructions:
    if char == '(':
        current_floor += 1
    elif char == ')':
        current_floor -= 1
print(f"2015 Day1 Part1 Answer: {current_floor}")

with open('/Users/kezhikun/PycharmProjects/advent_of_code_2015/input/day_01.txt', 'r') as file_object:
    instructions = file_object.read().strip()
current_floor = 0
first_basement_pos = -1
for pos, char in enumerate(instructions, start=1):
    if char == '(':
        current_floor += 1
    elif char == ')':
        current_floor -= 1
    if current_floor == -1 and first_basement_pos == -1:
        first_basement_pos = pos
        break
print(f"2015 Day1 Part2 Answer: {first_basement_pos}")