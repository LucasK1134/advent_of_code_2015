lights = [[False for _ in range(1000)] for _ in range(1000)]
with open('/Users/kezhikun/PycharmProjects/advent_of_code_2015/input/day_06.txt', 'r') as file_object:
    instructions = [line.strip() for line in file_object if line.strip()]
for line in instructions:
    parts = line.split()
    if parts[0] == 'toggle':
        cmd = 'toggle'
        start_coord = parts[1]
        end_coord = parts[3]
    else:
        cmd = parts[1]
        start_coord = parts[2]
        end_coord = parts[4]
    x1, y1 = map(int, start_coord.split(','))
    x2, y2 = map(int, end_coord.split(','))
    for y in range(y1, y2 + 1):
        for x in range(x1, x2 + 1):
            if cmd == 'on':
                lights[x][y] = True
            elif cmd == 'off':
                lights[x][y] = False
            elif cmd == 'toggle':
                lights[x][y] = not lights[x][y]
total_lit = sum(row.count(True) for row in lights)
print(f"2015 Day6 Part1 Answer: {total_lit}")

brightness_grid = [[0 for _ in range(1000)] for _ in range(1000)]
with open('/Users/kezhikun/PycharmProjects/advent_of_code_2015/input/day_06.txt', 'r') as file_object:
    instructions = [line.strip() for line in file_object if line.strip()]
for line in instructions:
    parts = line.split()
    if parts[0] == 'toggle':
        cmd = 'toggle'
        start_coord = parts[1]
        end_coord = parts[3]
    else:
        cmd = parts[1]
        start_coord = parts[2]
        end_coord = parts[4]
    x1, y1 = map(int, start_coord.split(','))
    x2, y2 = map(int, end_coord.split(','))
    for y in range(y1, y2 + 1):
        for x in range(x1, x2 + 1):
            if cmd == 'on':
                brightness_grid[x][y] += 1
            elif cmd == 'off':
                brightness_grid[x][y] = max(0, brightness_grid[x][y] - 1)
            elif cmd == 'toggle':
                brightness_grid[x][y] += 2
total_brightness = sum(sum(row) for row in brightness_grid)
print(f"2015 Day6 Part2 Answer: {total_brightness}")